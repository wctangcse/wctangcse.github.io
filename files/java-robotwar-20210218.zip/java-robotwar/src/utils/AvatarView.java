package utils;

import objects.Avatar;
import objects.GameObject;

import javax.swing.*;
import java.awt.*;
import java.util.Objects;

import static utils.GameView.drawImage;
import static utils.Types.TILETYPE.*;
import static utils.Types.VERBOSE;
import static utils.Utils.deepCopy;

public class AvatarView extends JComponent {

    private int cellSize;
    private GameObject[] avatars;
    @SuppressWarnings("FieldCanBeLocal")
    //private int offsetX = 40, offsetY = 18;
    private int offsetX = 18, offsetY = 40;
    private boolean[] alive;

    /**
     * Dimensions of the window.
     */
    private Dimension size;

    AvatarView(GameObject[] avatars)
    {
        alive = new boolean[avatars.length];
        this.cellSize = Types.AVATAR_ICON_SIZE; //(int) (cellSize * 2 / 3.0);
        //this.size = new Dimension(avatars.length * (this.cellSize + offsetX), this.cellSize + offsetY);
        // Matthew: vertical display
        this.size = new Dimension(this.cellSize * 4 + offsetX, avatars.length * (this.cellSize * 2 + offsetY));
        copyObjects(avatars);
        update(avatars);
    }

    public void paintComponent(Graphics gx)
    {
        Graphics2D g = (Graphics2D) gx;
        paintWithGraphics(g);
    }

    private void paintWithGraphics(Graphics2D g)
    {
        //For a better graphics, enable this: (be aware this could bring performance issues depending on your HW & OS).
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // increase the fontsize a bit
        Font currentFont = g.getFont();
        Font smallFont = currentFont;
        Font newFont = currentFont.deriveFont(currentFont.getSize() * 2.0F);
        g.setFont(newFont);

        // Paint avatars in a column: Matthew
        if (avatars != null) {
            for (int i = 0; i < avatars.length; i++) {
                GameObject o = avatars[i];
                if (o != null) {
                    //int x = i * (cellSize + offsetX); // Matthew
                    //int y = 0;
                    int y = i * (cellSize * 2 + offsetY); // Matthew
                    int x = 0;

                    if (!alive[i]) {
                        // If this avatar died, paint it with reduced opacity
                        Composite comp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f);
                        g.setComposite(comp);
                    } else {
                        // Full opacity otherwise
                        Composite comp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f);
                        g.setComposite(comp);
                    }

                    // Draw this avatar image
                    //Rectangle rect = new Rectangle(x, y + cellSize/4, cellSize, cellSize);
                    Rectangle rect = new Rectangle(x, y, cellSize, cellSize);
                    Image objImage = o.getImage();
                    drawImage(g, objImage, rect);
                    g.setFont(smallFont);
                    g.drawString(((Avatar)(o)).getName(), x + cellSize + 10, y + cellSize / 2);
                    g.setFont(newFont);

                    // Return to full opacity
                    Composite comp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f);
                    g.setComposite(comp);

                    // Draw win state
                    if (((Avatar)o).getWinner() != Types.RESULT.INCOMPLETE) {
                        g.setStroke(new BasicStroke(3));
                        g.setColor(((Avatar) o).getWinner().getColor());
                        g.drawRect(rect.x, rect.y, rect.width, rect.height);
                    }

                    if (!alive[i]) {
                        // Draw a skull on top of dead avatars.
                        int wh = cellSize / 2;
                        //rect = new Rectangle(x + wh, y, wh, wh);
                        rect = new Rectangle(x + wh/2, y + wh/2, wh, wh); // right in the middle
                        drawImage(g, Objects.requireNonNull(AGENTDUMMY.getImage()), rect);
                    }

                    _drawExtras(g, (Avatar)o, x, y + cellSize + 10); // leave 10-pixel gap
                } else {
                    if (VERBOSE) {
                        System.out.println("Avatar is null");
                    }
                }
            }
        }
    }

    private void _drawExtras(Graphics2D g, Avatar a, int x, int y) {
        g.setColor(Color.black);
        g.setStroke(new BasicStroke(1));

        int fontSize = g.getFont().getSize();

        int wh = cellSize / 3;
        int spacingPowerups = 10;

        String ammo = "" + a.getAmmo();
        //int offset1 = fontSize * ammo.length();
        int offset1 = wh; // 10 pixel vertical
        //String blast = "" + a.getBlastStrength();
        //int offset2 = wh; // 10 pixel vertical
        //int offset1 = fontSize * ammo.length();

        // Item 1: Ammo
        //Rectangle rect = new Rectangle(x, y, wh, wh);
        //drawImage(g, Objects.requireNonNull(EXTRABOMB.getImage()), rect);
        //drawImage(g, Objects.requireNonNull(FLAMES_UP.getImage()), rect);
        g.drawString(ammo, x + offset1, y + fontSize);
        //g.drawString(ammo, x + wh + spacingPowerups, y + fontSize);

        // Item 2: blast range
        //rect = new Rectangle(x + offset1 + spacingPowerups, y, wh, wh);
        //rect = new Rectangle(x, y + offset1 + spacingPowerups, wh, wh);
        //drawImage(g, Objects.requireNonNull(INCRRANGE.getImage()), rect);
        //g.drawString(blast, x + wh + spacingPowerups, y + offset1 + spacingPowerups + fontSize);
    }

    /**
     * @param avatars in the game
     */
    void paint(GameObject[] avatars)
    {
        update(avatars);
        this.repaint();
    }

    private void copyObjects(GameObject[] avatars)
    {
        this.avatars = deepCopy(avatars);
    }

    private void update(GameObject[] avatars)
    {
        this.avatars = new GameObject[this.avatars.length];
        for (int i = 0; i < avatars.length; i++) {
            alive[i] = avatars[i].getLife() != 0;
            this.avatars[i] = avatars[i];
        }
    }

    boolean[] getAlive() {
        return alive;
    }

    /**
     * Gets the dimensions of the window.
     * @return the dimensions of the window.
     */
    public Dimension getPreferredSize() {
        return size;
    }

}
