package players;

import core.GameState;
import utils.Types;
import java.util.Random;

public class DoNothingPlayer extends Player {
    public DoNothingPlayer(int pId) {
        super("DoNothingPlayer", 0, pId);
    }

    @Override
    public Types.ACTIONS act(GameState gs) {
        /* simulate a slow agent
        if ((new Random()).nextFloat() > 0.95) {
            long count = 0L;
            for (long x = 0; x < Integer.MAX_VALUE; x++)
                count++;
            if (count > 100)
                return Types.ACTIONS.ACTION_STOP;
        }
         */
        return Types.ACTIONS.ACTION_UP;
    }

    @Override
    public int[] getMessage() {
        // default message
        return new int[Types.MESSAGE_LENGTH];
    }

    @Override
    public Player copy() {
        return new DoNothingPlayer(playerID);
    }
}
