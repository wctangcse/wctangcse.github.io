package players;

import core.GameState;
import objects.Flame;
//import objects.Bomb;//should be commmented
import objects.GameObject;
import utils.Types;
import utils.Vector2d;

import java.util.*;

import static java.lang.Math.*;
import static utils.Utils.*;
import static utils.Utils.directionToAction;

public class SimplePlayer extends Player {
    private Random random;
    private ArrayList<Vector2d> recentlyVisitedPositions;
    private int recentlyVisitedLength;

    /**
     * Constructor.
     * @param seed seed for random moves.
     * @param id ID of this player.
     */
    public SimplePlayer(long seed, int id) {
        super("SimplePlayer", seed, id);
        reset(seed, id);
    }


    /**
     * Makes a copy of this player.
     * @return a deep copy of this player.
     */
    @Override
    public Player copy() {
        SimplePlayer player = new SimplePlayer(seed,playerID);
        player.recentlyVisitedPositions = new ArrayList<>();
        recentlyVisitedPositions.forEach(e -> player.recentlyVisitedPositions.add(e.copy()));
        player.recentlyVisitedLength = recentlyVisitedLength;
        //player.prevDirection = prevDirection;
        return player;
    }

    @Override
    public void reset(long seed, int playerID) {
        super.reset(seed, playerID);
        random = new Random(seed);

        this.recentlyVisitedPositions = new ArrayList<>();
        this.recentlyVisitedLength = 6;
    }

    // Container for return values of Dijkstra's pathfinding algorithm.
    public class Container
    {
        HashMap<Types.TILETYPE, ArrayList<Vector2d> > items;
        HashMap<Vector2d, Integer> dist;
        HashMap<Vector2d, Vector2d> prev;

        Container() { }
    }

    /**
     * Called every tick, returns the action to execute one each frame.
     * @param gs - current game state.
     * @return
     */
    @Override
    public Types.ACTIONS act(GameState gs) {
        // 1) Initialise the required information off GameState
        Vector2d myPosition = gs.getPosition();

        Types.TILETYPE[][] board = gs.getBoard();

        int ammo = gs.getAmmo();

        ArrayList<Types.TILETYPE> enemiesObs = gs.getAliveEnemyIDs();

        int boardSizeX = board.length;
        int boardSizeY = board[0].length;

        ArrayList<GameObject> enemies = new ArrayList<>();
        ArrayList<Flame> flames = new ArrayList<>();
        HashSet<Types.TILETYPE> flamesType = Types.TILETYPE.getFlamesTypes();

        for (int x = 0; x < boardSizeX; x++) {
            for (int y = 0; y < boardSizeY; y++) {
                Types.TILETYPE type = board[y][x];

                // collect the location of flames
                if (flamesType.contains(type)){
                    Flame f = new Flame(type.getDirection());
                    f.setPosition(new Vector2d(x, y));
                    flames.add(f);
                }
                else if(Types.TILETYPE.getAgentTypes().contains(type) &&
                        type.getKey() != gs.getPlayerId()){ // May be an enemy
                    if(enemiesObs.contains(type)) { // Is enemy
                        // Create enemy object
                        GameObject enemy = new GameObject(type);
                        enemy.setPosition(new Vector2d(x, y));
                        enemies.add(enemy); // no copy needed
                    }
                }
            }
        }

        // items: tile types with their coordinates
        // dist:  coordinates with their distance
        // prev:  shortest path with previous node and the distance to it
        Container from_dijkstra = dijkstra(board, myPosition, flames, enemies, 10);
        HashMap<Types.TILETYPE, ArrayList<Vector2d>> items = from_dijkstra.items;
        HashMap<Vector2d, Integer> dist = from_dijkstra.dist;
        HashMap<Vector2d, Vector2d> prev = from_dijkstra.prev;
        Iterator it;

        // 2) Move away from the coming flame(s)
        HashMap<Types.DIRECTIONS, Integer> unsafeDirections = directionsNearFlames(myPosition, flames, dist);
        if (!unsafeDirections.isEmpty()){
            ArrayList<Types.DIRECTIONS> directions =
                    findSafeDirections(board, myPosition, unsafeDirections, flames, enemies);
            if (!directions.isEmpty())
                return directionToAction(directions.get(random.nextInt(directions.size())));
            else
                return Types.ACTIONS.ACTION_STOP;
        }

        // 3) Shoot if we are close to an enemy.
        ArrayList<Types.ACTIONS> actions = getEnemyAtRange(myPosition, items, dist, enemies);
        if (!actions.isEmpty())
            return actions.get(random.nextInt(actions.size()));

        // 4) Move towards an enemy if there is one in exactly three reachable spaces.
        // check dist to nearest enemy
        // enemies - list of ArrayList of game objects
        for (GameObject en: enemies){
            Iterator dist_it = dist.entrySet().iterator(); // <Vector2d, Integer>
            while (dist_it.hasNext()){
                Map.Entry<Vector2d, Integer> entry = (Map.Entry)dist_it.next();

                if (entry.getKey().equals(en.getPosition()) && entry.getValue() == 3){
                    // pick this direction
                    Vector2d next_node = entry.getKey();
                    while (!myPosition.equals(prev.get(next_node))){
                        next_node = prev.get(next_node);
                    }
                    // return node, which had prev_node
                    return directionToAction(getDirection(myPosition, next_node));
                }
            }
        }

        // 5) Move towards ammo point if there is one within two reachable spaces and ammo < 3
        boolean needAmmo = ammo < 3;
        if (needAmmo) {
            it = items.entrySet().iterator();
            Vector2d previousNode = new Vector2d(-1, -1); // placeholder, these values are not actually used
            int distance = Integer.MAX_VALUE;
            while (it.hasNext()) {
                Map.Entry<Types.TILETYPE, ArrayList<Vector2d>> entry = (Map.Entry) it.next();
                // check pickup entries on the board
                if (Types.TILETYPE.getPowerUpTypes().contains(entry.getKey())) {
                    // no need to store just get closest
                    for (Vector2d coords: entry.getValue()) {
                        if (dist.get(coords) < distance) {
                            distance = dist.get(coords);
                            previousNode = coords;
                        }
                    }
                }
            }
            if (distance <= 2) {
                // iterate until we get to the immediate next node
                if (myPosition.equals(previousNode)) {
                    return directionToAction(getDirection(myPosition, previousNode));
                }
                while (!myPosition.equals(prev.get(previousNode))) {
                    previousNode = prev.get(previousNode);
                }
                return directionToAction(getDirection(myPosition, previousNode));
            }
        }

        // 6) Blast a wooden wall within a range
        it = items.entrySet().iterator();
        while (it.hasNext()) {
            final int woodRange = 3;
            final int desiredAmmo = 3;
            Map.Entry<Types.TILETYPE, ArrayList<Vector2d>> entry = (Map.Entry) it.next();
            // check pickup entries on the board
            if (entry.getKey().equals(Types.TILETYPE.WOOD) && ammo > desiredAmmo) {
                // check the distance from the wooden planks
                for (Vector2d coords : entry.getValue())
                    if (dist.get(coords) <= woodRange && (myPosition.x == coords.x || myPosition.y == coords.y))
                        return directionToShootAction(getDirection(myPosition, coords));
            }

        }

        // 8) Choose a random but valid direction.
        ArrayList<Types.DIRECTIONS> directions = new ArrayList<>();
        directions.add(Types.DIRECTIONS.UP);
        directions.add(Types.DIRECTIONS.DOWN);
        directions.add(Types.DIRECTIONS.LEFT);
        directions.add(Types.DIRECTIONS.RIGHT);
        ArrayList<Types.DIRECTIONS> validDirections = filterInvalidDirections(board, myPosition, directions, enemies);
        validDirections = filterUnsafeDirections(myPosition, validDirections, flames);
        validDirections = filterRecentlyVisited(validDirections, myPosition, this.recentlyVisitedPositions);

        // 9) Add this position to the recently visited uninteresting positions so we don't return immediately.
        recentlyVisitedPositions.add(myPosition);
        if (recentlyVisitedPositions.size() > recentlyVisitedLength)
            recentlyVisitedPositions.remove(0);

        if (validDirections.size() > 0){
            int actionIdx = random.nextInt(validDirections.size());
            return directionToAction(validDirections.get(actionIdx));
        }

        return Types.ACTIONS.ACTION_STOP;
    }

    @Override
    public int[] getMessage() {
        // default message
        return new int[Types.MESSAGE_LENGTH];
    }

    /**
     * Dijkstra's pathfinding
     * @param board - game board
     * @param myPosition - the position of agent
     * @param flames - array of flames in the game
     * @param enemies - array of enemies in the game
     * @param depth - depth of search (default: 10)
     * @return A set of paths to the different elements in the game.
     */
    private Container dijkstra(Types.TILETYPE[][] board, Vector2d myPosition, ArrayList<Flame> flames,
                               ArrayList<GameObject> enemies, int depth){
        HashMap<Types.TILETYPE, ArrayList<Vector2d> > items = new HashMap<>();
        HashMap<Vector2d, Integer> dist = new HashMap<>();
        HashMap<Vector2d, Vector2d> prev = new HashMap<>();

        Queue<Vector2d> Q = new LinkedList<>();

        for(int r = max(0, myPosition.x - depth); r < min(board.length, myPosition.x + depth); r++){
            for(int c = max(0, myPosition.y - depth); c < min(board.length, myPosition.y + depth); c++){
                Vector2d position = new Vector2d(r, c);

                // Determines if two points are out of range of each other.
                boolean out_of_range = (abs(c - myPosition.y) + abs(r - myPosition.x)) > depth;
                if (out_of_range)
                    continue;

                // Determine if the tile cannot be moved into (Rigid or Fog or Flames)
                Types.TILETYPE itemType = board[c][r];
                boolean positionInItems = ( itemType == Types.TILETYPE.FOG ||
                                            itemType == Types.TILETYPE.RIGID ||
                                            Types.TILETYPE.getFlamesTypes().contains(itemType));
                if (positionInItems)
                    continue;

                ArrayList<Vector2d> itemsTempList = items.get(itemType);
                if (itemsTempList == null) { // this is the first one
                    itemsTempList = new ArrayList<>();
                }
                itemsTempList.add(position);
                items.put(itemType, itemsTempList);

                if (position.equals(myPosition)){
                    Q.add(position);
                    dist.put(position, 0);
                }
                else {
                    dist.put(position, Integer.MAX_VALUE);
                }
            }
        }

        while(!Q.isEmpty()){
            Vector2d position = Q.remove();

            if (positionIsPassable(board, position, enemies)){
                int val = dist.get(position) + 1;

                Types.DIRECTIONS[] directionsToBeChecked =
                        {Types.DIRECTIONS.LEFT, Types.DIRECTIONS.RIGHT, Types.DIRECTIONS.UP, Types.DIRECTIONS.DOWN};

                for (Types.DIRECTIONS directionToBeChecked : directionsToBeChecked) {
                    Vector2d direction = directionToBeChecked.toVec();
                    Vector2d new_position = new Vector2d(position.x + direction.x, position.y + direction.y);

                    if(!dist.containsKey(new_position))
                        continue;

                    int dist_val = dist.get(new_position);
                    if (val < dist_val){
                        dist.put(new_position, val);
                        prev.put(new_position, position);
                        Q.add(new_position);
                    }
                    else if (val == dist_val && random.nextFloat() < 0.5){
                        dist.put(new_position, val);
                        prev.put(new_position, position);
                    }
                }
            }
        }

        Container container = new Container();
        container.dist = dist;
        container.items = items;
        container.prev = prev;

        return container;
    }

    /**
     * Calculates those directions from the agent's posititon that are in the direction of a flame.
     * @param myPosition - Position of this agent.
     * @param flames - List of flames in the board now
     * @param dist - The list of distances to all flames.
     * @return A set of directions that would fall in the bomb explosion range.
     */
    private HashMap<Types.DIRECTIONS, Integer> directionsNearFlames(Vector2d myPosition, ArrayList<Flame> flames,
            HashMap<Vector2d, Integer> dist) {
        HashMap<Types.DIRECTIONS, Integer> ret = new HashMap<>();

        for (Flame f: flames){
            Vector2d position = f.getPosition();
            if (!dist.containsKey(position))
                continue;

            int distance = dist.get(position);
            Types.DIRECTIONS direction = f.getDirection();

            if (distance > 2) // no immediate danger
                continue;

            if (myPosition.x > position.x && myPosition.y == position.y && direction == Types.DIRECTIONS.RIGHT) {
                // flame is on my left and coming towards me
                ret.put(Types.DIRECTIONS.LEFT, myPosition.x - position.x);
            }
            else if (myPosition.x < position.x && myPosition.y == position.y && direction == Types.DIRECTIONS.LEFT) {
                // flame is on my right and coming towards me
                ret.put(Types.DIRECTIONS.RIGHT, position.x - myPosition.x);
            }
            else if (myPosition.x == position.x && myPosition.y > position.y && direction == Types.DIRECTIONS.DOWN) {
                // flame is above and coming towards me
                ret.put(Types.DIRECTIONS.UP, myPosition.y - myPosition.y);
            }
            else if (myPosition.x == position.x && myPosition.y < position.y && direction == Types.DIRECTIONS.UP) {
                // flame is below and coming towards me
                ret.put(Types.DIRECTIONS.DOWN, position.y - myPosition.y);
            }
        }
        return ret;
    }


    /**
     * Finds a list of directions that is Safe to move to.
     * @param board - Current game board
     * @param myPosition - Current position of the agent.
     * @param unsafeDirections - Set of previously determined unsafe directions.
     * @param flames - List of flames currently in hte game.
     * @param enemies - List of enemies in hte game.
     * @return A set of directions that would be safe to move (may be empty)
     */
    private ArrayList<Types.DIRECTIONS> findSafeDirections(Types.TILETYPE[][] board, Vector2d myPosition,
                                                           HashMap<Types.DIRECTIONS, Integer> unsafeDirections,
                                                           ArrayList<Flame> flames, ArrayList<GameObject> enemies) {
        ArrayList<Types.DIRECTIONS> safe = new ArrayList<>();
        // the directions that will go off the board.
        Set<Types.DIRECTIONS> disallowed = new HashSet<>();

        Types.DIRECTIONS[] directions = {Types.DIRECTIONS.LEFT, Types.DIRECTIONS.RIGHT,
                Types.DIRECTIONS.UP, Types.DIRECTIONS.DOWN};

        // look for a list of safe directions to move
        for (Types.DIRECTIONS dir: directions) {
            Vector2d position = myPosition.copy();
            Vector2d nextPosition = position.add(dir.toVec());

            if (!positionOnBoard(board, nextPosition)){
                disallowed.add(dir);
                continue;
            }

            if (unsafeDirections.containsKey(dir)) // unsafe, skip
                continue;

            if (positionIsPassable(board, nextPosition, enemies))
                safe.add(dir);

        }

        return safe;
    }

    /**
     * Checks if there's an adjecent enemy.
     * @param objects - Game objects in the board.
     * @param dist - Distance to different positions around me.
     * @param enemies - Set of enemy players.
     * @return true if an agent is next to this player.
     */
    private ArrayList<Types.ACTIONS> getEnemyAtRange(
            Vector2d myPosition,
            HashMap<Types.TILETYPE, ArrayList<Vector2d> > objects,
            HashMap<Vector2d, Integer> dist,
            ArrayList<GameObject> enemies)
    {
        final int range = 2;
        ArrayList<Types.ACTIONS> ret = new ArrayList<Types.ACTIONS>();
        for(GameObject enemy: enemies){
            if (objects.containsKey(enemy.getType())) {
                ArrayList<Vector2d> items_list = objects.get(enemy.getType());
                for (Vector2d position: items_list) {
                    if (dist.get(position) > range)
                        continue;
                    if (myPosition.x != position.x && myPosition.y != position.y)
                        continue;
                    Types.DIRECTIONS dir = getDirection(myPosition, position);
                    if (dir == Types.DIRECTIONS.DOWN)
                        ret.add(Types.ACTIONS.ACTION_SHOOT_DOWN);
                    else if (dir == Types.DIRECTIONS.UP)
                        ret.add(Types.ACTIONS.ACTION_SHOOT_UP);
                    else if (dir == Types.DIRECTIONS.RIGHT)
                        ret.add(Types.ACTIONS.ACTION_SHOOT_RIGHT);
                    else if (dir == Types.DIRECTIONS.LEFT)
                        ret.add(Types.ACTIONS.ACTION_SHOOT_LEFT);
                }
            }
        }
        return ret;
    }

    /**
     * Checks unsafe directions of movements, where a flame could hit me
     * @param myPosition - The position the agent is in
     * @param directions - Directions I could move towards
     * @param flames - current set of flames in the level
     * @return The list of safe directions to move to.
     */
    private ArrayList<Types.DIRECTIONS> filterUnsafeDirections(Vector2d myPosition,
                                                               ArrayList<Types.DIRECTIONS> directions,
                                                               ArrayList<Flame> flames){
        ArrayList<Types.DIRECTIONS> safeDirections = new ArrayList<>();
        for (Types.DIRECTIONS dir: directions){
            Vector2d myPos = getNextPosition(myPosition, dir);
            boolean isBad = false;
            for (Flame f: flames) {
                if (myPosition == f.getPosition())
                    isBad = true;
            }
            if (!isBad){
                safeDirections.add(dir);
            }
        }
        return safeDirections; // contains all for now
    }

    /**
     * List of valid directions from current position. Avoids leaving board and moving against walls.
     * @param board - The current board.
     * @param myPosition - Position of this agent.
     * @param directions - Possible directions to move to
     * @param enemies - List of enemies in the game.
     * @return A subset of the directions received that would be valid to move to
     */
    private ArrayList<Types.DIRECTIONS> filterInvalidDirections(Types.TILETYPE[][] board,
                                                                Vector2d myPosition, ArrayList<Types.DIRECTIONS> directions,
                                                                ArrayList enemies){
        ArrayList<Types.DIRECTIONS> validDirections = new ArrayList<>();
        for (Types.DIRECTIONS d: directions){
            Vector2d position = getNextPosition(myPosition, d);
            if (positionOnBoard(board, position) && (positionIsPassable(board, position, enemies))){
                validDirections.add(d);
            }
        }
        return validDirections;
    }

    /**
     * Checks for directions that would take the agent to positions that have been recently visted.
     * @param directions - Set of initial possible directions
     * @param myPosition - Current position of the agent.
     * @param recentlyVisitedPositions - set of recently visited positions.
     * @return A subset of the directions received that would be okay to move to
     */
    private ArrayList<Types.DIRECTIONS> filterRecentlyVisited(ArrayList<Types.DIRECTIONS> directions,
                                                              Vector2d myPosition, ArrayList<Vector2d> recentlyVisitedPositions){
        ArrayList<Types.DIRECTIONS> filtered = new ArrayList<>();
        for (Types.DIRECTIONS d : directions){
            if (!recentlyVisitedPositions.contains(getNextPosition(myPosition, d)))
                filtered.add(d);
        }
        if (filtered.size() > 0)
             return directions;

        return filtered;
    }
}