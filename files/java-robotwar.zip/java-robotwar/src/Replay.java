import core.Game;
import players.*;
import utils.Types;
import utils.GameLog;

import java.util.ArrayList;

public class Replay {
    public static void main(String[] args) {
        assert(args.length == 1);
        String path = args[0];
        System.out.println("Loading recorded game from the JSON file \"" + path + "\" ...");

        // Game parameters
        int boardSize = Types.BOARD_SIZE;
        boolean useSeparateThreads = false;
        Types.FRAME_DELAY = 100; // smaller delay gives faster replay
        Game.LOG_GAME_JSON = true;

        // Key controllers for human player s (up to 2 so far). Not used anyway
        KeyController ki1 = new KeyController(true);
        KeyController ki2 = new KeyController(false);

        Game replay = Game.loadGamefromJSON(path); // give absolute path
        Run.runGame(replay, ki1, ki2, false);
    }

}
