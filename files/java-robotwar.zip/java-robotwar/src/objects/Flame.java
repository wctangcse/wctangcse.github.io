package objects;

import utils.Types;

import static utils.Types.FLAME_LIFE;

public class Flame extends GameObject {

    public int playerIdx;
    private Types.DIRECTIONS dir;

    public Flame(){
        this(Types.DIRECTIONS.NONE);
    }

    public Flame(Types.DIRECTIONS dir) {
        super(Types.TILETYPE.FLAMES_UP);
        if (dir == Types.DIRECTIONS.UP)
            this.type = Types.TILETYPE.FLAMES_UP;
        else if (dir == Types.DIRECTIONS.DOWN)
            this.type = Types.TILETYPE.FLAMES_DOWN;
        else if (dir == Types.DIRECTIONS.LEFT)
            this.type = Types.TILETYPE.FLAMES_LEFT;
        else if (dir == Types.DIRECTIONS.RIGHT)
            this.type = Types.TILETYPE.FLAMES_RIGHT;
        life = FLAME_LIFE;
        this.dir = dir;
    }

    @Override
    public void tick(){
        this.life--;
        desiredCoordinate = position.copy();
    }

    @Override
    public GameObject copy() {
        Flame copy = new Flame();
        copy.life = life;
        if (position != null) {
            copy.position = position.copy();
        }
        copy.desiredCoordinate = desiredCoordinate.copy();
        copy.id = hashCode();
        return copy;
    }
    public Types.DIRECTIONS getDirection() {
        return dir;
    }
}
