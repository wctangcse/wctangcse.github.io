package players;

import core.GameState;
import utils.Types;

import java.util.Random;
import java.util.ArrayList;

public class RandomPlayer extends Player {
    private Random random;

    public RandomPlayer(long seed, int id) {
        super("RandomPlayer", seed, id);
        reset(seed, id);
    }

    @Override
    public void reset(long seed, int playerID) {
        //super(seed, playerID);
        random = new Random(seed);
    }

    @Override
    public Types.ACTIONS act(GameState gs) {
        ArrayList<Types.ACTIONS> acts;
        if (random.nextFloat() < 0.8) {
            acts = Types.ACTIONS.moveActions();
            int actionIdx = random.nextInt(acts.size());
            return acts.get(actionIdx);
        }
        else {
            acts = Types.ACTIONS.shootActions();
            int actionIdx = random.nextInt(acts.size());
            return acts.get(actionIdx);
        }
    }

    @Override
    public int[] getMessage() {
        // default message
        return new int[Types.MESSAGE_LENGTH];
    }

    @Override
    public Player copy() {
        return new RandomPlayer(seed, playerID);
    }
}
