import core.Game;
import players.*;
import utils.Types;

import java.util.ArrayList;

public class Test {

    public static void main(String[] args) {

        // Game parameters
        long seed = System.currentTimeMillis();
        int boardSize = Types.BOARD_SIZE;
        Types.GAME_MODE gameMode = Types.GAME_MODE.FFA;
        boolean useSeparateThreads = false;
        Game.LOG_GAME_JSON = true;
        Game game = new Game(seed, boardSize, Types.GAME_MODE.FFA, "");

        // Key controllers for human player s (up to 2 so far).
        KeyController ki1 = new KeyController(true);
        KeyController ki2 = new KeyController(false);

        // Create players
        ArrayList<Player> players = new ArrayList<>();
        int playerID = Types.TILETYPE.AGENT0.getKey();

        //players.add(new HumanPlayer(ki1, playerID++));
        //players.add(new HumanPlayer(ki2, playerID++));
        //players.add(new DoNothingPlayer(playerID++));
        players.add(new DoNothingPlayer(playerID++));
        players.add(new RandomPlayer(seed, playerID++));
        //players.add(new RandomPlayer(seed, playerID++));
        players.add(new RandomPlayer(seed, playerID++));
        //players.add(new SimplePlayer(seed, playerID++));
        players.add(new SimplePlayer(seed, playerID++));
        //players.add(new SimplePlayer(seed, playerID++));

        // Make sure we have exactly NUM_PLAYERS players
        assert players.size() == Types.NUM_PLAYERS : "There should be " + Types.NUM_PLAYERS +
                " added to the game, but there are " + players.size();

        //Assign players and run the game.
        game.setPlayers(players);
        game.setLogGame(true);

        //Run a single game with the players
        //Run.runGame(game, ki1, ki2, useSeparateThreads);
        //Run.runGames(game, new long[]{seed}, 20, useSeparateThreads);
        /* Uncomment to run the replay of the previous game: */

        /*
        if (game.isLogged()){
            Game replay = Game.getLastReplayGame();

            Run.runGame(replay, ki1, ki2, useSeparateThreads);
            assert(replay.getGameState().equals(game.getGameState()));
        }
         */

        /* Run with no visuals, N Times: */
//        int N = 20;
//        Run.runGames(game, new long[]{seed}, N, useSeparateThreads);

    }

}
